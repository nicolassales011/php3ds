<?php session_start(); session_destroy(); ?>
<h1>Jogo da Forca</h1>
<form action="game.php" method="post">
Nome Jogador 1:<input name="j1" required><br><br>
Nome Jogador 2:<input name="j2" required><br><br>
Palavra:<input type="password" name="palavra" required><br><br>
<button>Começar</button>
</form>