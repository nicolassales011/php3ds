<?php
session_start();
file_put_contents("ranking.txt",$_SESSION['j2']." - ".$_SESSION['pontos']." pontos\n",FILE_APPEND);
echo "<h1>Fim de jogo</h1>";
echo "Pontuação: ".$_SESSION['pontos']."<br>";
echo "<a href='ranking.php'>Ranking</a><br>";
echo "<a href='index.php'>Jogar novamente</a>";
session_destroy();
?>