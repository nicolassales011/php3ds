<?php
session_start();

if(!isset($_SESSION['palavra'])){
    $_SESSION['j1']=$_POST['j1'];
    $_SESSION['j2']=$_POST['j2'];
    $_SESSION['palavra']=strtoupper($_POST['palavra']);
    $_SESSION['usadas']=[];
    $_SESSION['erros']=0;
    $_SESSION['pontos']=0;
}

if(isset($_POST['letra'])){
    $l=strtoupper($_POST['letra']);
    if(!in_array($l,$_SESSION['usadas'])){
        $_SESSION['usadas'][]=$l;

        if(strpos($_SESSION['palavra'],$l)!==false){
            $_SESSION['pontos']+=10;
        } else {
            $_SESSION['erros']++;
        }
    }
}

$forca=['😀','🙂','😐','😕','😟','😣','💀'];

echo "<h2>Forca ".$forca[$_SESSION['erros']]."</h2>";
echo "Jogador: ".$_SESSION['j2']."<br>";
echo "Pontos: ".$_SESSION['pontos']."<br>";
echo "Tentativas restantes: ".(6-$_SESSION['erros'])."<br><br>";

$ok=true;

foreach(str_split($_SESSION['palavra']) as $c){
    if(in_array($c,$_SESSION['usadas'])){
        echo $c." ";
    } else {
        echo "_ ";
        $ok=false;
    }
}

if($ok || $_SESSION['erros']>=6){
    header('Location: resultado.php');
    exit;
}

echo "<br><br>Letras usadas: ".implode(",",$_SESSION['usadas']);
?>

<form method="post">
<input maxlength="1" name="letra" required>
<button>Enviar</button>
</form>
